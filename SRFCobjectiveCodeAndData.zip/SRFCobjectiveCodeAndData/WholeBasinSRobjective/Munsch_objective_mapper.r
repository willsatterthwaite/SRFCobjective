
#parameters of flow-modified Ricker fit by Munsch et al. 2020
a=3.129803366 #productivity
b=0.222388609 #strength of density dependence
c=0.451906811 #flow effect
#note that these are meant to apply to spawners measured in 100K fish, and flow on log scale

log.median.flow=log(515) #From Munch et al. 2020, p. 1490
F=log.median.flow #could explore other flow scenarios also -- but this just scales things up and down so not super interesting for now

esc.dat=read.csv("RefPeriodEscapements.csv")
srfc.comp.adult.esc=esc.dat$SRFC.composite.adults
nat.spawners.3run.esc=esc.dat$SRFC.nat.spawners+esc.dat$SRWC.nat.spawners+esc.dat$SRSC.nat.spawners

cor(srfc.comp.adult.esc,nat.spawners.3run.esc)
# 0.9868808

S.k=c(1:500)
R=exp(log(a)+log(S.k/100)-b*(S.k/100)+c*F) #Munsch et al. 2020, p. 1503
#S.k is divided by 100 because Munsch et al. 2020 is parameterized based on escapements in 100Ks of fish

esc.goal.prod=array(NA,c(19,20))
esc.goal.both=array(NA,c(19,20))
for (prob.step in 1:19)
{#prob.step
	prob.achieve=prob.step*.05
	for (prod.step in 1:20)
	{#prod.step
		frac.prod=0.05*prod.step
		nat.esc.needed=min(which(R>=(frac.prod*max(R))))*1000 #x1000 to get back to units of fish
		nat.esc.sufficient=nat.spawners.3run.esc>nat.esc.needed
		hat.returns.sufficient=(esc.dat$Coleman.fall.adults>12000)*(esc.dat$Feather.fall.adults>6000)*(esc.dat$Nimbus.fall.adults>4000)
		both.esc.sufficient=nat.esc.sufficient*hat.returns.sufficient
		log.reg.prod=glm(nat.esc.sufficient ~ srfc.comp.adult.esc, family = "binomial")
		log.reg.both=glm(both.esc.sufficient ~ srfc.comp.adult.esc, family = "binomial")		
		srfc.esc.needed.prod=min(which(plogis(coef(log.reg.prod)[1]+coef(log.reg.prod)[2]*(S.k*1000))>prob.achieve)) #in 100K fish
		srfc.esc.needed.both=min(which(plogis(coef(log.reg.both)[1]+coef(log.reg.both)[2]*(S.k*1000))>prob.achieve)) #in 100K fish
		esc.goal.prod[prob.step,prod.step]=srfc.esc.needed.prod
		esc.goal.both[prob.step,prod.step]=srfc.esc.needed.both
		
	}#prod.step
}#prob.step

pdf("SpawnerCorrespondence.pdf",height=5,width=8)
plot(srfc.comp.adult.esc/1000,nat.spawners.3run.esc/1000,xlab="SRFC composite adult escapment (thousands)",ylab="Natural area fall/spring/winter spawners (thousands)",main="Predicting total natural F/S/W spawners from SRFC adults")
dev.off()

pdf("WholeBasinProductionGoal.pdf",height=7,width=8)
contour(x=c(1:19),y=c(1:20),esc.goal.prod,main="b) Sacramento Basin natural production",axes=FALSE,ylab="fraction of maximum natural production",xlab="probability of achieving escapement expected to yield production goal",labcex=1.1,levels=c(60,122,180,240,300,360,420,480,540))
axis(side=1,at=c(1:19),labels=c(1:19)/20)
axis(side=2,at=c(1:20),labels=c(1:20)/20,las=2)
dev.off()

pdf("WholeBasinProductionAndHatcheryGoal.pdf",height=7,width=8)
contour(x=c(1:19),y=c(1:20),esc.goal.both,main="b) Sacramento Basin natural and hatchery goals",axes=FALSE,ylab="fraction of maximum natural production",xlab="probability of achieving escapement expected to yield production goal, and hatchery goals",labcex=1.1,levels=c(60,122,180,240,300,360,420,480,540))
axis(side=1,at=c(1:19),labels=c(1:19)/20)
axis(side=2,at=c(1:20),labels=c(1:20)/20,las=2)
dev.off()

hat.esc.sufficient=(esc.dat$Coleman.fall.adults>12000)*(esc.dat$Feather.fall.adults>6000)*(esc.dat$Nimbus.fall.adults>4000)
log.reg.hat=glm(hat.esc.sufficient ~ srfc.comp.adult.esc, family = "binomial")


#How likely to achieve hatchery goals at 122K?
plogis(coef(log.reg.hat)[1]+coef(log.reg.hat)[2]*(122000))
#(Intercept) 
#   0.6572834 

#What fraction of potential production at 122K?
R[122]/max(R)
#[1] 0.5622594

#How likely to achieve hatchery goals at 180K?
plogis(coef(log.reg.hat)[1]+coef(log.reg.hat)[2]*(180000))
#(Intercept) 
#   0.9933447  

#What fraction of potential production at 180K?
R[180]/max(R)
#[1] 0.729175


