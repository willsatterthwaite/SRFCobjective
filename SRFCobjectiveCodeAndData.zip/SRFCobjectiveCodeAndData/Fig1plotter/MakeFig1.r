# use Ogle's FSA package to fit S-R relationships
library(FSA)

#load data on Upper Sac natural production
srfc.jpi.dat=read.csv("../UpperSacSRbasedObjective/UpperSacFemalesJPI.csv")

# Fitting the Ricker #3 parameterization with multiplicative errors
r3 <- srFuns("Ricker",param=3)
r3s <- srStarts(JPI.srfc~Upper.Sac.Nat.Females.srfc,data=srfc.jpi.dat,type="Ricker",param=3)
fit2 <- nls(log(JPI.srfc)~log(r3(Upper.Sac.Nat.Females.srfc,a,Rp)),data=srfc.jpi.dat,start=r3s)
summary(fit2,correlation=TRUE)
pdf(height=6,width=12,"Fig1.pdf")
par(mfrow=c(1,2))
plot(srfc.jpi.dat$Upper.Sac.Nat.Females.srfc,srfc.jpi.dat$JPI.srfc,main="a) Upper Sacramento natural production",xlab="Female natural area spawners above RBDD",ylab="Juvenile production (million fry equivalents)",yaxt="n",cex=2.5)
axis(side=2,at=5000000*c(0:7),labels=5*c(0:7),las=1)
curve(r3(x,a=coef(fit2)[1],Rp=coef(fit2)[2]),from=0,to=200000,col="blue",lwd=3,add=TRUE)

#load data on Sacramento natural production
basin.production.dat=read.csv("../MunschEtAlModel/table_for_will.csv")

plot(basin.production.dat$spawners_sac_not_LF_100k*100000,basin.production.dat$sac_abundance_estimate,main="b) Sacramento Basin natural production",xlab="Natural area fall, spring, and winter spawners",ylab="Sacramento River fry density index",cex=2.5,las=1,xaxt="n")
axis(side=1,at=c(200000,400000,600000,800000),labels=c("200000","400000","600000","800000"))
points(x=basin.production.dat$spawners_sac_not_LF_100k*100000,y=basin.production.dat$sac_abundance_estimate,pch=21,cex=2.5,bg=grey(1-(basin.production.dat$median_flow_ms_log.s+2)/4.5))

spawner.range=c(0:80)/10
alpha=log(3.129803366)
beta=0.222388609
flow.coef=0.451906811
sr.mean=exp(alpha)*spawner.range*exp(-beta*spawner.range)
sr.hi=exp(alpha+flow.coef)*spawner.range*exp(-beta*spawner.range)
sr.lo=exp(alpha-flow.coef)*spawner.range*exp(-beta*spawner.range)
lines(spawner.range*100000,sr.mean,col="blue",lwd=3)
lines(spawner.range*100000,sr.hi,col="blue",lwd=3,lty=3)
lines(spawner.range*100000,sr.lo,col="blue",lwd=3,lty=3)


dev.off()
