dat=read.csv("RefPeriodEscapements.csv")
postseason=dat$SRFC.composite.adults
preseason.recent=dat$PreseasonSRFCadults

mu.recent=mean(log(preseason.recent/postseason),na.rm=TRUE)
median.recent=exp(mu.recent)
sdlog.recent=sd(log(preseason.recent/postseason),na.rm=TRUE)

pdf(height=6,width=12,"EscapementPredictionAbility-Recent.pdf")
par(mfrow=c(1,2))
hist(preseason.recent/postseason,breaks=c(0:40)/10,freq=FALSE,main="a) Preseason/postseason escapement ratios, 2014-2021",xlab="preseason expectation / postseason estimate")
lines(x=c(0:40)/10,y=dlnorm(c(0:40)/10,meanlog=mu.recent,sdlog=sdlog.recent))

plot(preseason.recent/1000,postseason/1000,xlab="Preseason expectation (thousands)",ylab="Postseason estimate (thousands)",main="b) Escapement predictive performance, 2014-2021",las=1,pch=20,xlim=c(0,400),ylim=c(0,400))
hatchery.esc=dat$Coleman.fall.adults+dat$Feather.fall.adults+dat$Nimbus.fall.adults
points(preseason.recent/1000,hatchery.esc/1000)
lines(x=c(0,400),y=c(0,400),lty=3)

dev.off()