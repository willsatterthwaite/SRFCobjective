#read in escapements to various areas to relate SRFC adult escapement to meeting production and hatchery goals
esc.dat=read.csv("RefPeriodEscapements.csv")
srfc.comp.adult.esc=esc.dat$SRFC.composite.adults

S.k=c(1:500)
hat.esc.sufficient=(esc.dat$Coleman.fall.adults>12000)*(esc.dat$Feather.fall.adults>6000)*(esc.dat$Nimbus.fall.adults>4000)
log.reg.hat=glm(hat.esc.sufficient ~ srfc.comp.adult.esc, family = "binomial")
pdf("HatcheryGoalLogisticRegression.pdf",height=5,width=8)
plot(esc.dat$SRFC.composite.adults/1000,hat.esc.sufficient,xlab="Composite SRFC adult escapement (thousands)",ylab="Prob. meet goals",main="Probability of meeting hatchery goals",xlim=c(0,800))
eval=plogis(coef(log.reg.hat)[1]+coef(log.reg.hat)[2]*(S.k*1000))
lines(S.k,eval)
dev.off()

#minimum escapement for 5% probability of meeting goals
min(which(eval>0.05))
# 79 [thousand]


#minimum escapement for 50% probability of meeting goals
min(which(eval>=0.50))
# 111 [thousand]


#minimum escapement for 95% probability of meeting goals
min(which(eval>0.95))
# 143 [thousand]

#minimum escapement for which success was observed
min(srfc.comp.adult.esc[which(hat.esc.sufficient==1)])
#104483

#maximum escapement for which failure was observed
max(srfc.comp.adult.esc[which(hat.esc.sufficient==0)])
#124276

#How likely to achieve hatchery goals at 122K?
plogis(coef(log.reg.hat)[1]+coef(log.reg.hat)[2]*(122000))
#(Intercept) 
#[1] 0.7434327 

#How likely to achieve hatchery goals at 180K?
plogis(coef(log.reg.hat)[1]+coef(log.reg.hat)[2]*(180000))
#(Intercept) 
#  0.9984207