library(MASS)
#read in escapements to various areas to relate SRFC adult escapement to meeting production and hatchery goals
esc.dat=read.csv("TotalAndHatcheryEscapements.csv")
srfc.comp.adult.esc=esc.dat$SRFC.composite.adults
hat.esc.sufficient=(esc.dat$Coleman.fall.adults>12000)*(esc.dat$Feather.fall.adults>6000)*(esc.dat$Nimbus.fall.adults>4000)
input_data=data.frame(sufficient=hat.esc.sufficient,esc=srfc.comp.adult.esc)

#fit logistic regression model
log.reg.hat=glm(sufficient ~ esc, data=input_data,family = binomial(link=logit))
pdf("HatcheryGoalLogisticRegressionWithCI.pdf",height=5,width=8)
plot(esc.dat$SRFC.composite.adults/1000,hat.esc.sufficient,xlab="Composite SRFC adult escapement (thousands)",ylab="Prob. meet goals",main="Probability of meeting hatchery goals",xlim=c(0,800))
#set up predictions of best fit and confidence intervals
new=data.frame(sucess=array(1,c(80,1)),esc=c(1:80)*10000)
pred.prob <- predict(log.reg.hat, newdata = new, type = "response")
pred.eta <- predict(log.reg.hat, newdata = new, type = "link", se = TRUE)
CI.lower <- pred.eta$fit - 1.96 * pred.eta$se.fit
CI.upper <- pred.eta$fit + 1.96 * pred.eta$se.fit
CI.lower=plogis(CI.lower)
CI.upper=plogis(CI.upper)
lines(x=new$esc/1000,y=pred.prob)
lines(x=new$esc/1000,y=CI.lower,lty=2)
lines(x=new$esc/1000,y=CI.upper,lty=2)
dev.off()
#plot without CI
pdf("HatcheryGoalLogisticRegression.pdf",height=5,width=8)
plot(esc.dat$SRFC.composite.adults/1000,hat.esc.sufficient,xlab="Composite SRFC adult escapement (thousands)",ylab="Prob. meet goals",main="Probability of meeting hatchery goals",xlim=c(0,800))
#set up predictions of best fit and confidence intervals
new=data.frame(sucess=array(1,c(80,1)),esc=c(1:80)*10000)
pred.prob <- predict(log.reg.hat, newdata = new, type = "response")
pred.eta <- predict(log.reg.hat, newdata = new, type = "link", se = TRUE)
CI.lower <- pred.eta$fit - 1.96 * pred.eta$se.fit
CI.upper <- pred.eta$fit + 1.96 * pred.eta$se.fit
CI.lower=plogis(CI.lower)
CI.upper=plogis(CI.upper)
lines(x=new$esc/1000,y=pred.prob)
#lines(x=new$esc/1000,y=CI.lower,lty=2)
#lines(x=new$esc/1000,y=CI.upper,lty=2)
dev.off()


#set up a vector of predicted success probabiluty as functon of escapement (in thousands)
S.k=c(1:500)
e.val=plogis(coef(log.reg.hat)[1]+coef(log.reg.hat)[2]*(S.k*1000))
#minimum escapement for 5% probability of meeting goals
min(which(e.val>0.05))
# 49 [thousand]

#minimum escapement for 95% probability of meeting goals
min(which(e.val>0.95))
# 362 [thousand]

#minimum escapement for 50% probability of meeting goals
min(which(e.val>=0.50))
# 205  [thousand]

#minimum escapement for which success was observed
min(srfc.comp.adult.esc[which(hat.esc.sufficient==1)])
#104483

#maximum escapement for which failure was observed
max(srfc.comp.adult.esc[which(hat.esc.sufficient==0)])
#240103.4

#How likely to achieve hatchery goals at 122K?
plogis(coef(log.reg.hat)[1]+coef(log.reg.hat)[2]*(122000))
#(Intercept) 
#[1] 0.173389 

#How likely to achieve hatchery goals at 180K?
plogis(coef(log.reg.hat)[1]+coef(log.reg.hat)[2]*(180000))
#(Intercept) 
#  0.3849443