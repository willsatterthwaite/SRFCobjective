# use Ogle's FSA package to fit S-R relationships
library(FSA)

#load data on Upper Sac natural production
srfc.jpi.dat=read.csv("UpperSacFemalesJPI.csv")

# Fitting the Ricker #3 parameterization with multiplicative errors
r3 <- srFuns("Ricker",param=3)
r3s <- srStarts(JPI.srfc~Upper.Sac.Nat.Females.srfc,data=srfc.jpi.dat,type="Ricker",param=3)
fit2 <- nls(log(JPI.srfc)~log(r3(Upper.Sac.Nat.Females.srfc,a,Rp)),data=srfc.jpi.dat,start=r3s)
summary(fit2,correlation=TRUE)
pdf(height=6,width=6,"UpperSacS-Rplot.pdf")
plot(srfc.jpi.dat$Upper.Sac.Nat.Females.srfc,srfc.jpi.dat$JPI.srfc,main="a) Upper Sacramento natural production",xlab="Female natural area spawners above RBDD",ylab="Juvenile production (million fry equivalents)",yaxt="n",cex=2.5)
axis(side=2,at=5000000*c(0:7),labels=5*c(0:7),las=1)
curve(r3(x,a=coef(fit2)[1],Rp=coef(fit2)[2]),from=0,to=200000,col="blue",lwd=3,add=TRUE)
dev.off()

#expression for calculating production (vs Upper Sac nat females) as fraction of maximum possible production
a=coef(fit2)[1]
Ricker.alpha=log(a)
Rp=coef(fit2)[2]
Smsp=Rp*exp(1)/a
Ricker.beta=1/Smsp
spawner.range=c(1:2000000) #this can be made more efficient, kind of excessive and un-necessary level of precision
production.range=a*spawner.range*exp(-a*spawner.range/(Rp*exp(1)))

#read in escapements to various areas to relate SRFC adult escapement to meeting production and hatchery goals
esc.dat=read.csv("RefPeriodEscapements.csv")
srfc.comp.adult.esc=esc.dat$SRFC.composite.adults
uppersac.females=esc.dat$UpperSacNat.females

cor(srfc.comp.adult.esc,uppersac.females,use="pairwise.complete.obs")
# 0.8976032

#see when escapement is sufficient to meet production and maybe also hatchery goals
esc.goal.prod=array(NA,c(19,20))
esc.goal.both=array(NA,c(19,20))
for (prob.step in 1:19)
{#prob.step
	prob.achieve=prob.step*.05
	for (prod.step in 1:20)
	{#prod.step
		frac.prod=0.05*prod.step
		usnf.esc.needed=min(which(production.range>=(frac.prod*Rp)))
		usnf.esc.sufficient=uppersac.females>usnf.esc.needed
		hat.returns.sufficient=(esc.dat$Coleman.fall.adults>12000)*(esc.dat$Feather.fall.adults>6000)*(esc.dat$Nimbus.fall.adults>4000)
		both.esc.sufficient=usnf.esc.sufficient*hat.returns.sufficient
		log.reg.prod=glm(usnf.esc.sufficient ~ srfc.comp.adult.esc, family = "binomial")
		log.reg.both=glm(both.esc.sufficient ~ srfc.comp.adult.esc, family = "binomial")		
		srfc.esc.needed.prod=min(which(plogis(coef(log.reg.prod)[1]+coef(log.reg.prod)[2]*spawner.range)>prob.achieve)) 
		srfc.esc.needed.both=min(which(plogis(coef(log.reg.both)[1]+coef(log.reg.both)[2]*spawner.range)>prob.achieve)) 
		esc.goal.prod[prob.step,prod.step]=srfc.esc.needed.prod
		esc.goal.both[prob.step,prod.step]=srfc.esc.needed.both		
	}#prod.step
}#prob.step 

pdf("UpperSacSpawnerCorrespondence.pdf",height=5,width=8)
plot(srfc.comp.adult.esc/1000,uppersac.females/1000,xlab="SRFC composite adult escapment (thousands)",ylab="Upper Sacramento natural feamles (thousands)",main="Predicting upper Sacramento natural females from SRFC adults")
dev.off()

pdf("UpperSacProductionGoal.pdf",height=7,width=8)
contour(x=c(1:19),y=c(1:20),esc.goal.prod/1000,main="a) Upper Sacramento natural production",axes=FALSE,ylab="fraction of maximum natural production",xlab="probability of achieving escapement expected to yield production goal",labcex=1.1,levels=c(60,122,180,240,300,360,420,480,540))
axis(side=1,at=c(1:19),labels=c(1:19)/20)
axis(side=2,at=c(1:20),labels=c(1:20)/20,las=2)
text(9.5,18,">480K needed, insufficient high escapement data to say how much")
dev.off()

#Will's interpretation: pretty confident that an adult escapement of 180K will yield 27K Upper Sac females to yield 60% of maximum produciton
#Achieving more than this is modeled to be unlikely
#Modeled to be very unlikely to produce more than upper Sac females needed for 80% of maximum production
# min(which(production.range>0.6*Rp))
#[1] 27345
# min(which(production.range>0.8*Rp))
# [1] 43414

pdf("UpperSacProductionAndHatcheryGoal.pdf",height=7,width=8)
contour(x=c(1:19),y=c(1:20),esc.goal.both/1000,main="a) Upper Sacramento natural & hatchery goals",axes=FALSE,ylab="fraction of maximum natural production",xlab="probability of achieving escapement expected to yield production goal, and hatchery goals",labcex=1.1,levels=c(60,122,180,240,300,360,420,480,540))
axis(side=1,at=c(1:19),labels=c(1:19)/20)
axis(side=2,at=c(1:20),labels=c(1:20)/20,las=2)
text(9.5,18,">480K needed, insufficient high escapement data to say how much")
dev.off()

#Will's interpreation:
#60K total adult spawners unlikely to meet hatchery goals
#122K total adult spawners reasonably likely to meet hatchery goals, but not with really high confidence, so slight shifft in that countour
#180K total adult spawners almost certain to meet hatchery goals, so higher contours unchanged

hat.esc.sufficient=(esc.dat$Coleman.fall.adults>12000)*(esc.dat$Feather.fall.adults>6000)*(esc.dat$Nimbus.fall.adults>4000)
log.reg.hat=glm(hat.esc.sufficient ~ srfc.comp.adult.esc, family = "binomial")
#How likely to achieve hatchery goals at 122K?
plogis(coef(log.reg.hat)[1]+coef(log.reg.hat)[2]*(122000))
#(Intercept) 
# 0.7434327 

#what median adult SRFC escapement have we achieved?
median(srfc.comp.adult.esc,na.rm=TRUE)
#131183.5 

#what median female escapement to natural areas above RBDD have we achieved?
median(uppersac.females,na.rm=TRUE)
#[1] 23302

#what fraction of potential production does this yield?
production.range[median(uppersac.females,na.rm=TRUE)]/Rp 
#0.5342574 

#what was median JPI?
median(srfc.jpi.dat$JPI.srfc)
#[1] 9886303

#what fraction of modeled maximum production is this?
median(srfc.jpi.dat$JPI.srfc)/Rp
#0.3673128  

#what was maximum JPI estimate?
max(srfc.jpi.dat$JPI.srfc)
#[1] 33201448

#what proportion of maximum observed production was median production?
median(srfc.jpi.dat$JPI.srfc)/max(srfc.jpi.dat$JPI.srfc)
#[1] 0.2977672

