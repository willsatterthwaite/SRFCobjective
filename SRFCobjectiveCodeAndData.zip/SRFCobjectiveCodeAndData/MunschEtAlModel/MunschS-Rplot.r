#load data on Sacramento natural production
basin.production.dat=read.csv("table_for_will.csv")



pdf(height=6,width=6,"BasinS-Rplot.pdf")
plot(basin.production.dat$spawners_sac_not_LF_100k*100000,basin.production.dat$sac_abundance_estimate,main="b) Sacramento Basin natural production",xlab="Natural area fall, spring, and winter spawners",ylab="Sacramento River fry density index",cex=2.5,las=1,xaxt="n")
axis(side=1,at=c(200000,400000,600000,800000),labels=c("200000","400000","600000","800000"))
points(x=basin.production.dat$spawners_sac_not_LF_100k*100000,y=basin.production.dat$sac_abundance_estimate,pch=21,cex=2.5,bg=grey(1-(basin.production.dat$median_flow_ms_log.s+2)/4.5))

spawner.range=c(0:80)/10
alpha=log(3.129803366)
beta=0.222388609
flow.coef=0.451906811
sr.mean=exp(alpha)*spawner.range*exp(-beta*spawner.range)
sr.hi=exp(alpha+flow.coef)*spawner.range*exp(-beta*spawner.range)
sr.lo=exp(alpha-flow.coef)*spawner.range*exp(-beta*spawner.range)
lines(spawner.range*100000,sr.mean,col="blue",lwd=3)
lines(spawner.range*100000,sr.hi,col="blue",lwd=3,lty=3)
lines(spawner.range*100000,sr.lo,col="blue",lwd=3,lty=3)


dev.off()
